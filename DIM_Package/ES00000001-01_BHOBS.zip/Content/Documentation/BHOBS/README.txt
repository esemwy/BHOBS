# BHOBS
As one who strives for realism in many respects, your Genesis 2 figure should do what real shooters do. Namely,
index along the frame of the pistol (or rifle) until you're ready to fire. Gun people say to keep your Booger
Hook Off the Bang Switch, giving this set of poses its name.

They are only partial poses, effecting only Carpal1 and Index1,2 & 3.

Consider these released under the Creative Commons BY 3.0 (text provided separately). Essentially that
means you can do anything you like with these *including repackaging in commercial products*, but you have 
to give proper credit.
